/* author: andre balassiano A01387418 &
              luiz tatemoto A01396704      */

$(document).ready(function(){
    
    let roundTracker = 0;
    let isSpinning = true;
    let animationHandler;
    let rollStartTime;
    let roundOutcomeString ="";
    
    let d1NxtRdom = 1;
    let d2NxtRdom = 2;
    let d3NxtRdom = 3;
    let d4NxtRdom = 4;
    
    let d1CurrVal = 0;
    let d2CurrVal = 0;
    let d3CurrVal = 0;
    let d4CurrVal = 0;
    
    let totalPlayerScore = 0;
    let totalOpponentScore = 0;
    
    const idleAnimationInterval = 800;
    const rollingAnimationInterval = 80;

    const $roundKeeper = $("#round-keeper");
    const $rollBtn = $("#roll-button");
    const $resetBtn = $("#reset-button");
    const $gameOutcome = $("#game-outcome");
    
    const $d1 = $("#dice1");
    const $d2 = $("#dice2");
    const $d3 = $("#dice3");
    const $d4 = $("#dice4");
    
    const $d1Legend = $("#dice1-legend");
    const $d2Legend = $("#dice2-legend");
    const $d3Legend = $("#dice3-legend");
    const $d4Legend = $("#dice4-legend");
    
    const $roundScorePlayer = $("#round-score-player");
    const $roundScoreOpponent = $("#round-score-opponent");
    
    const $roundOutcomeElementPlayer = $("#round-outcome-player");
    const $roundOutcomeElementOpponent = $("#round-outcome-opponent");
    
    const $totalScorePlayerElement = $("#total-score-player");
    const $totalScoreOpponentElement = $("#total-score-opponent");

    // idle spinning animation for when page loads
    function spinDiceIdle(){
        if (isSpinning){
            updateImagesAndValues();
            setTimeout(function(){
                animationHandler = requestAnimationFrame(spinDiceIdle);
            }, idleAnimationInterval);
        }
    }

    
    //
    //
    // functions are in order of calling once roll event is triggered
    //
    //
    
    // stops idle animation and calls date getter function for fast animation call
    function rollDice(){
        $rollBtn.prop("disabled", true);
        cancelAnimationFrame(animationHandler);
        getDateForRoll();
    }
    
    // gets current date for the timer on the fast roll and calls fast animation function
    function getDateForRoll(){
        rollStartTime = Date.now();
        spinDiceFast();
    }
    
    // animates fast spin for 1s and calls dice stop function
    function spinDiceFast(){
        if (Date.now() - rollStartTime < 1000) {
            updateImagesAndValues();
            setTimeout(function(){
                animationHandler = requestAnimationFrame(spinDiceFast);
            }, rollingAnimationInterval)

        } else {
            stopDice();
        }
    }

    // stops dice animations and calls game updated function
    function stopDice(){
        isSpinning = false;
        $rollBtn.prop("disabled", false);
        cancelAnimationFrame(animationHandler);
        roundTracker++;
        updateGameState();
    }

    // updates all relevant scores and trackers. calls game end function upon 3rd round completion
    function updateGameState(){
        let playerRollResult;
        let opponentRollResult;

        $d1Legend.text(`Legend: ${d1CurrVal}`);
        $d2Legend.text(`Legend: ${d2CurrVal}`);
        $d3Legend.text(`Legend: ${d3CurrVal}`);
        $d4Legend.text(`Legend: ${d4CurrVal}`);

        $roundKeeper.text(`Rounds Completed: ${roundTracker}/3`);

        playerRollResult = processRoll(d1CurrVal, d2CurrVal);
        $roundOutcomeElementPlayer.text(roundOutcomeString);
        
        opponentRollResult = processRoll(d3CurrVal, d4CurrVal);
        $roundOutcomeElementOpponent.text(roundOutcomeString);

        $roundScorePlayer.text(`Round Score: ${playerRollResult}`);
        $roundScoreOpponent.text(`Round Score: ${opponentRollResult}`);

        totalPlayerScore += playerRollResult;
        totalOpponentScore += opponentRollResult;

        $totalScorePlayerElement.text(`Total Score: ${totalPlayerScore}`);
        $totalScoreOpponentElement.text(`Total Score: ${totalOpponentScore}`);

        if (roundTracker === 3){
            endGame();
        }
    }

    // ends game and displays the result
    function endGame(){
        $rollBtn.prop("disabled", true);
        $rollBtn.text("Game Over");
        $rollBtn.css({
            "opacity": "0.6",
            "cursor": "not-allowed",
        });
        
        if (totalPlayerScore > totalOpponentScore){
            $gameOutcome.html(`You <em>WON!</em> You scored ${totalPlayerScore} points!<br>
                                Your skill with random numbers is amazing! :0`);
            
        } else if (totalPlayerScore < totalOpponentScore){
            $gameOutcome.html(`You <em>LOST!</em> Honestly, ${totalPlayerScore} points is garbage...<br>
                                Maybe you should've praticed rolling dice some more :P`);
            
        } else {
            $gameOutcome.html(`<em>DRAW!</em> Play again and show the opponent who is boss?`);
        }
    }

    // resets the game to new state
    function resetGame(){
        isSpinning = true;
        roundTracker = 0;
        totalPlayerScore = 0;
        totalOpponentScore = 0;
        d1CurrVal = "";
        d2CurrVal = "";
        d3CurrVal = "";
        d4CurrVal = "";
        $gameOutcome.text("")
        $rollBtn.prop("disabled", false);
        $rollBtn.text("Roll Dice");
        $rollBtn.css({
            "opacity": "1",
            "cursor": "pointer",
        });        
        updateGameState();
        spinDiceIdle();
    }

    //
    //
    // utility functions
    //
    //

    // updates dice images and values
    function updateImagesAndValues(){
        d1NxtRdom = getRandom();
        d2NxtRdom = getRandom();
        d3NxtRdom = getRandom();
        d4NxtRdom = getRandom();

        while (d1NxtRdom === d1CurrVal) {
            d1NxtRdom = getRandom();
        }
        while (d2NxtRdom === d2CurrVal) {
            d2NxtRdom = getRandom();
        }
        while (d3NxtRdom === d3CurrVal) {
            d3NxtRdom = getRandom();
        }
        while (d4NxtRdom === d4CurrVal) {
            d4NxtRdom = getRandom();
        }

        d1CurrVal = d1NxtRdom;
        d2CurrVal = d2NxtRdom;
        d3CurrVal = d3NxtRdom;
        d4CurrVal = d4NxtRdom;

        $d1.attr("src", `img/playerD${d1NxtRdom}.png`);
        $d2.attr("src", `img/playerD${d2NxtRdom}.png`);
        $d3.attr("src", `img/opponentD${d3NxtRdom}.png`);
        $d4.attr("src", `img/opponentD${d4NxtRdom}.png`);
    }

    // gets random number 1-6
    function getRandom(){
        return Math.floor(Math.random()*6) + 1;
    }

    // processes the score based on roll results
    function processRoll(d1,d2){
        if(d1 === 1 || d2 === 1){
            roundOutcomeString = "Rolled a 1, zero points!"
            return 0;

        } else if (d1 === "" ||d1 === ""){
            roundOutcomeString = "Roll the dice!";
            return 0;
            
        } else if(d1 === d2){
            roundOutcomeString = "Same number pair, big points!"
            return ((d1+d2)*2);

        } else {
            roundOutcomeString = "Good roll!"
            return (d1+d2);
        }
    }

    // roll event binder
    $rollBtn.click(rollDice);

    // reset game binder
    $resetBtn.click(resetGame);

    // starts idle spin on page load
    spinDiceIdle();

});